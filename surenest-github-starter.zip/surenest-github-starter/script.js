// SureNest public website starter. Update the WhatsApp number before launch.
const SURENEST_WHATSAPP_NUMBER = ""; // Example format: "919802023536" (country code + number, digits only)

const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");
menuToggle.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));
document.getElementById("year").textContent = new Date().getFullYear();

function openWhatsApp(message) {
  if (!SURENEST_WHATSAPP_NUMBER) {
    const status = document.getElementById("formStatus");
    status.textContent = "Before using WhatsApp enquiries, add your business number to SURENEST_WHATSAPP_NUMBER in script.js.";
    status.className = "search-result show";
    return;
  }
  const url = "https://wa.me/" + SURENEST_WHATSAPP_NUMBER + "?text=" + encodeURIComponent(message);
  window.open(url, "_blank", "noopener,noreferrer");
}

function makeSearchMessage(location, type) {
  return `Hello SureNest, I would like to enquire about ${type} in ${location}. Please share currently available options and details.`;
}
document.getElementById("propertySearch").addEventListener("submit", event => {
  event.preventDefault();
  const location = document.getElementById("location").value;
  const type = document.getElementById("propertyType").value;
  const result = document.getElementById("searchResult");
  result.innerHTML = `<strong>Requirement selected: ${escapeHTML(type)} in ${escapeHTML(location)}</strong><br>Availability and pricing need to be confirmed by the SureNest team.`;
  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = "Enquire on WhatsApp";
  btn.addEventListener("click", () => openWhatsApp(makeSearchMessage(location, type)));
  result.appendChild(document.createElement("br"));
  result.appendChild(btn);
  result.classList.add("show");
});
document.querySelectorAll(".location-card").forEach(card => {
  card.addEventListener("click", () => {
    document.getElementById("location").value = card.dataset.location;
    document.getElementById("find").scrollIntoView({behavior:"smooth"});
    document.getElementById("location").focus({preventScroll:true});
  });
});
document.getElementById("contactForm").addEventListener("submit", event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const message = [
    "Hello SureNest, I have a property enquiry.",
    `Name: ${data.get("name")}`,
    `Phone: ${data.get("phone")}`,
    `Interest: ${data.get("interest")}`,
    `Requirement: ${data.get("message") || "Not provided"}`
  ].join("\n");
  openWhatsApp(message);
});
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[char]));
}
