# SureNest Website Starter

A responsive static website starter for SureNest Private Limited.

## Files
- `index.html` — website content and sections
- `styles.css` — visual design and responsive layout
- `script.js` — menu, location/property search form, WhatsApp enquiry preparation

## Preview locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a GitHub repository named `surenest-platform` (or your preferred name).
2. Upload `index.html`, `styles.css`, `script.js`, and this README to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for the published URL to appear in Pages settings.

## Before launch
- In `script.js`, set `SURENEST_WHATSAPP_NUMBER` to the approved business WhatsApp number in international digits-only format, e.g. `9198XXXXXXXX`.
- Confirm the public contact details, services, service areas, privacy notice, and all claims.
- Add a privacy policy and terms appropriate for your actual business and data practices.
- Do not collect or expose private client data in this static site.

## Important limitations
This is a front-end starter, not a complete real estate CRM. It has no secure login, database, partner permissions, property verification backend, or persistent lead storage. GitHub Pages can host the public static website, but the partner dashboard and private lead management need a secure backend and authentication before real client data is used.
